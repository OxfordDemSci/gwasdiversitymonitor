the final datasets which are created by ```generate_data.py``` and power the interactive plots
